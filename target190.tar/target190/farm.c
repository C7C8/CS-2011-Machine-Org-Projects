/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_145(unsigned *p)
{
    *p = 2425393240U;
}

unsigned getval_190()
{
    return 3804436522U;
}

unsigned addval_494(unsigned x)
{
    return x + 3281031384U;
}

void setval_490(unsigned *p)
{
    *p = 2421709628U;
}

void setval_247(unsigned *p)
{
    *p = 3284633928U;
}

void setval_100(unsigned *p)
{
    *p = 2445773128U;
}

unsigned getval_458()
{
    return 3347925135U;
}

unsigned addval_101(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_415()
{
    return 3222847881U;
}

unsigned addval_224(unsigned x)
{
    return x + 2447411528U;
}

void setval_197(unsigned *p)
{
    *p = 3284208072U;
}

void setval_320(unsigned *p)
{
    *p = 3229141641U;
}

unsigned addval_400(unsigned x)
{
    return x + 3523794569U;
}

void setval_340(unsigned *p)
{
    *p = 3229931017U;
}

unsigned addval_186(unsigned x)
{
    return x + 3527983497U;
}

void setval_153(unsigned *p)
{
    *p = 3286276424U;
}

unsigned getval_221()
{
    return 3281049241U;
}

unsigned getval_443()
{
    return 3599335167U;
}

unsigned getval_393()
{
    return 3286239560U;
}

unsigned addval_257(unsigned x)
{
    return x + 3353381192U;
}

void setval_282(unsigned *p)
{
    *p = 3525891721U;
}

void setval_324(unsigned *p)
{
    *p = 3378566793U;
}

void setval_372(unsigned *p)
{
    *p = 4006073993U;
}

unsigned getval_169()
{
    return 3524840073U;
}

unsigned addval_208(unsigned x)
{
    return x + 3376988553U;
}

void setval_231(unsigned *p)
{
    *p = 3677407881U;
}

void setval_273(unsigned *p)
{
    *p = 2430634312U;
}

unsigned addval_328(unsigned x)
{
    return x + 3221804683U;
}

unsigned getval_312()
{
    return 3281046152U;
}

unsigned addval_135(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_132()
{
    return 3374893705U;
}

unsigned addval_124(unsigned x)
{
    return x + 3374367113U;
}

void setval_451(unsigned *p)
{
    *p = 2445969915U;
}

unsigned getval_446()
{
    return 3221799177U;
}

void setval_294(unsigned *p)
{
    *p = 3380923017U;
}

unsigned addval_477(unsigned x)
{
    return x + 2430634304U;
}

void setval_448(unsigned *p)
{
    *p = 3675832713U;
}

void setval_390(unsigned *p)
{
    *p = 3766569211U;
}

unsigned getval_250()
{
    return 3284830547U;
}

void setval_210(unsigned *p)
{
    *p = 3281043849U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
